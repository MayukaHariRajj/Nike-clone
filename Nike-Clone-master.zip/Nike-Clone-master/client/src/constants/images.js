import nikeLogo from '../assets/Nike-logo.png';
import nikeLogoPayment from '../assets/nikeLogoPayment.png'


export { nikeLogo, nikeLogoPayment };