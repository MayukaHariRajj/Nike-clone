import { SET_NAVBAR_PATH } from "./actionTypes";


export const setNavbarPath = (payload) => {
    return { type: SET_NAVBAR_PATH, payload };
};


