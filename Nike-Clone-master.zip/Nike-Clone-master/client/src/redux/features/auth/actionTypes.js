export const SHOW_LOGIN_PAGE = "SHOW_LOGIN_PAGE";
export const SHOW_RESET_PAGE = "SHOW_RESET_PAGE";
export const GET_TOKEN = "GET_TOKEN";
export const REMOVE_TOKEN = "REMOVE_TOKEN";